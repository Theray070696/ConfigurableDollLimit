Someone asked me for this.

This mod lets you configure the max amount of dolls (or Forgive Me Please's) you can have active at once. Default is 3 as Hopoo set.

NOTE: I take no responsibility for your PC or Risk of Rain 2 crashing due to too many dolls being active at once. There's a reason this mod is configurable and not hard set at a stupidly high number.


Want to support my modding? Support me on Patreon! https://www.patreon.com/Theray070696

___
Changelog:

1.0.0:
-Initial release